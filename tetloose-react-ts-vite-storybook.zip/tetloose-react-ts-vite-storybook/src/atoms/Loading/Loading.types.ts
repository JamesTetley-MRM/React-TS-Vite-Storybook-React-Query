import type { GlobalColor, GlobalModifiers } from '@global/global.types'

export type LoadingProps = {
  center?: boolean
} & GlobalColor &
  GlobalModifiers
