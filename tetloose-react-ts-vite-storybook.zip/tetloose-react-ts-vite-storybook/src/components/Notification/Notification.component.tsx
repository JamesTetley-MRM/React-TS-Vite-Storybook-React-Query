import { Toaster } from 'react-hot-toast'

export const Notification = () => <Toaster />
