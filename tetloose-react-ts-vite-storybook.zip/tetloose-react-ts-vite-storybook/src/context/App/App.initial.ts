import type { AppProps } from './App.types'

export const initialApp: AppProps = {
  welcome: 'Happy Coding!'
}
