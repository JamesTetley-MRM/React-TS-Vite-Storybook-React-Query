export type AppProps = {
  welcome: string
}
