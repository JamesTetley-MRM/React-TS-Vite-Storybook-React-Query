import type { Column, Row } from './get-styles.types'

export type CalcGrid = {
  rows?: Row
  columns?: Column
  template: boolean
}
