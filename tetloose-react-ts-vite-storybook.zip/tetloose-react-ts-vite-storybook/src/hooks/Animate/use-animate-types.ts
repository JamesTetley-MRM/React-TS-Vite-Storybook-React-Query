export type UseAnimateTransition = 'is-visible' | 'is-hidden'

export type UseAnimateReturn = UseAnimateTransition
