export type NotificationType = 'default' | 'success' | 'error' | 'loading'
